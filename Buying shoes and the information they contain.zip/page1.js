let containerElem = document.querySelector('.container')

let arrayProduct = [
    { id: 1, title: 'Best shoes', description: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea, veniam', src: '../images/0000-800.jpg', price: 53 },
    { id: 2, title: 'Women shoes', description: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea, veniam', src: '../images/71J-XEv+ScL._AC_SL1500_.jpg', price: 87 },
    { id: 3, title: 'Boots', description: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea, veniam', src: '../images/images.jpeg', price: 34 }
]



let fragment = document.createDocumentFragment()

arrayProduct.forEach(function (item) {

    let newElemDivCard = document.createElement('div')
    let newElemh1 = document.createElement('h1')
    let newElemP = document.createElement('p')
    let newElemImg = document.createElement('img')
    let newElemDivBox = document.createElement('div')
    let newElemDivPrice = document.createElement('div')
    let newElemABtn = document.createElement('a')

    newElemDivCard.classList.add('product-card')
    newElemDivBox.classList.add('box')
    newElemDivPrice.classList.add('product-price')
    newElemABtn.classList.add('product-btn')

    newElemDivBox.append(newElemDivPrice, newElemABtn)
    newElemDivCard.append(newElemh1, newElemP, newElemImg, newElemDivBox)

    newElemh1.textContent = item.title
    newElemP.textContent = item.description
    newElemImg.src = item.src
    newElemDivPrice.textContent = item.price
    newElemABtn.textContent = 'See More'
    newElemABtn.href = 'product.html?id=' + item.id

    fragment.append(newElemDivCard)


})
containerElem.append(fragment)


let btn = document.querySelector('.btn')

btn.addEventListener('click', function () {
    location.reload()
    location.assign()
    location.replace()
})