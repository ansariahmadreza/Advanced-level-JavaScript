let btn = document.querySelector('.btn')
let imgElem = document.querySelector('.img')
let h1Elem = document.querySelector('.h1Elem')
let pElemDec = document.querySelector('.pElemDec')

btn.addEventListener('click', function () {
    history.back()
})


let arrayProduct = [
    {id: 1, title: 'Best shoes', description: 'ssimus dolorehicneque placeat autem libero, saepe nobis facilis odit esse, commodi omnis, qui optio tenetur incidunt estullam accusantium culpa fugiat illo.Suscipit rerum totam dolores dolore neque! Incidunt eligendinostrumipsam aperiamomnisplaceatnesciunt(Best shoes)', src: '../images/0000-800.jpg'},
    { id: 2, title: 'Women shoes', description: 'Lorem ipsum dolorajfbhahfakfsgakfsgakjfsgakjfsgakjfslgaskjgfakjsflgaskjlfagssfkjlagsfkjagfskagfakjsfgaksjfgaskjlfagsfkj sit amet consectetur adipisicing elit. Ea, veniam(Women shoes)', src: '../images/71J-XEv+ScL._AC_SL1500_.jpg' },
    { id: 3, title: 'Boots', description: 'Lorem ipsum dolor sit aafhalkjfhaafshakjfshaksjfhakjsfhakjsfhakjsfhalskfjhalskjfhlaskjfhsafskjlhakfsjhakjsfhaslfkjhkajfhlaskjfhlaskfllaskjflhaksjfhmet consectetur adipisicing elit. Ea, veniam(Boots)', src: '../images/images.jpeg' }
]


let searchParams = new URLSearchParams(location.search)
let getId = Number(searchParams.get('id'))


let resultId = arrayProduct.find(function (item) {
    return item.id == getId
})


if (resultId) {

    h1Elem.textContent = resultId.title
    pElemDec.textContent = resultId.description
    imgElem.src = resultId.src

} else {
    location.href = 'http://127.0.0.1:5501/src/html/'
}


