let suggestions = [
    "Channel",
    "CodingLab",
    'DevCraft',
    'CodeSphere',
    'TechLabs',
    'ZAHRA',
    'ZAZA',
    'I think something is wrong with my code, but Icantfigureitout.',
    'Let me try to break it down step by step.',
    'I expected a different result, so I need to trace the data.',
    'Maybe theres a logical error Im not seeing yet.',
    'Ill add some console logs to see whats really happening'
]

/// فراخوانی عناصر مورد نیاز
let inputValueElem = document.querySelector('.inputValue')
let autocomBox = document.querySelector('.box')
let searchInput = document.querySelector('.search-input')


function filterItem() {
    autocomBox.innerHTML = ''/// خالی کردن باکس پیشنهادات

    let searchValue = inputValueElem.value // ذخیره مقدار input

    if (/^[A-Za-zآ-ی]+$/.test(searchValue)) {////  فقط فارسی یا انگلیسی بدون حروف و بدون فاصله مورد تایید است
        searchInput.classList.add('active') /// دادن کلاس که باعث نمایش منوی پیشنهادات میشه
        /// فیلتر کردن کلمات مشابه وارد شده توسط کاربر در ارایه بالا
        let resultFilter = suggestions.filter(item => item.toLowerCase().includes(inputValueElem.value.toLowerCase()))
        /// فراخوانی تابع
        suggestionsGenerator(resultFilter)

    } else {
        /// ذز صورتی که  ورودی نامعتبر باشد یا ادامه کد نادرس باشد کلاس حذف میشود و تابع متوقف میشود
        searchInput.classList.remove('active')
        return
    }
}

function suggestionsGenerator(itemsFilter) {

    let resultMap = itemsFilter.map(function (word) {// ساخت li برای تمام کلمات فیلتر شده
        return "<li>" + word + "</li>"
    })
    let customList;// عامل افزایش خوانایی نگهداری و توسعه کد
///وقتی یک عملیات یا مقدار قرار است در چند جای مختلف تکرار شود یا چند مرحله روی آن انجام شود، ذخیره کردن آن در یک متغیر کاملاً منطقی و توصیه‌شده است.
    if (!itemsFilter.length) {/// اگر ورودی در بین کلمات فیلتر شده نبود کد های بعدی اجرا بشه
        customList = '<li>' + inputValueElem.value + '</li>'
        alert('داده مورد نظر یافت نشد')
    } else {
        /// در صورت معتبر بودن ورودی نتیجه نهایی به متغیر اضافه بشه با حذف فاصله های نامناسب
        customList = resultMap.join('')

    }

    autocomBox.innerHTML = customList/// اضافه کردن در dom
    selectedLi()/// فراخوانی تابع پایینی
}

function selectedLi() {

    let infoAllItem = autocomBox.querySelectorAll('li')/// فراخوانی li های add شده به dom

    infoAllItem.forEach(function (item) {/// اجرای foreach روی پیشنهاداتُ
        item.addEventListener('click', function () { // اجرای event کلیک 
            inputValueElem.value = item.textContent /// برابر قرار دادن مقدار item با مقدار input
            searchInput.classList.remove('active')/// حذف کردن کلاسی که باعث نمایش پیشنهادات میشه
            
        })    
    })
}

inputValueElem.addEventListener('keyup', filterItem)/// اجرای event keyup روی input



